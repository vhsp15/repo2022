from geral.config import *
from geral.cripto import *
from modelo.pessoa import *

@app.route("/login", methods=['POST'])
def login():
    
    resposta = jsonify({"resultado": "ok", "detalhes": "ok"})
    
    dados = request.get_json(force=True)  
    login = dados['login']
    senha = dados['senha']

   
    encontrado = Pessoa.query.filter_by(email=login, senha=cifrar(senha)).first()
    if encontrado is not None:
        session[login] = "OK"
    else:
        resposta = jsonify({"resultado": "erro", "detalhes": "login e/ou senha inválido(s)"})        
   
    resposta.headers.add("Access-Control-Allow-Origin", meuservidor)
    
    resposta.headers.add("Access-Control-Allow-Credentials", "true")
    return resposta 