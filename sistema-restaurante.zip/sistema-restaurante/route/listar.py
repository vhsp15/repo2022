from geral.config import *
from modelo.pessoa import *

@app.route("/listar/<string:classe>", methods=['POST'])
def listar(classe):

    dados = request.get_json(force=True)

    
    if 'login' not in dados:
        resposta = jsonify({"resultado": "erro", "detalhes": "ausência de login na requisição"})
    else:
        
        login = dados['login']
        
        valor = None
        try:
            valor = session[login]
            print("valor na sessão: " + valor)
        except Exception as e:
            print("não encontrado: "+str(e))
        if valor == None:
            resposta = jsonify({"resultado": "erro", "detalhes": "ausência de login "+dados['login']+" na sessão"})
        else:    
            dados = None
            if classe == "Pessoa":
                dados = db.session.query(Pessoa).all()

            
            lista_jsons = [x.json() for x in dados]
           
            resposta = jsonify({"resultado":"ok","detalhes":lista_jsons})

    resposta.headers.add("Access-Control-Allow-Origin", meuservidor)
  
    resposta.headers.add("Access-Control-Allow-Credentials", "true")
    return resposta